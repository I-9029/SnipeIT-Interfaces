<!--

~~ Check-in Information ~~

DB: snipeit
Table: asset_logs  &&  assets

asset_logs Columns:
id: Auto
user_id: int User of program - Default for desk?


//Double check this value!\\
action_type: checkin from


asset_id: int Returned from scan
checkedout_to: ???????							//DOUBLE CHECK
location_id: NULL
created_at: timestamp, yyyy-mm-dd hh:mm:ss
asset_type: From data returned from scan
note: Notes field
updated_at: Same as created_at



asset Columns (where id = id of asset by tag (auto-incr from 1)):
assigned_to: NULL
Updated_at: timstamp, yyyy-mm-dd hh:mm:ss (same as created_at from other table)
last_checkout: NULL
expected_checkin: NULL

-->
<?php
	//Get and store date
	ini_set('date.timezone','EST');
	$date = new DateTime();
	$friendlyDate = "".($date->format('m-d-Y H:i:s'));

	//DB conn
	include "db/connect.php";

	//Decode data
	$json = file_get_contents('php://input');
	$listData = json_decode($json,true);

	//Store data posted
	$scan = $listData["scan"];
	$notes = $listData["notes"];

	//Default helpdesk user ID
	$sender = 1;

	/*
	We need:
		ID from Assets
		Asset Type from Assets
		Notes passed in post
	*/

	//Queries because typing takes too long
	function mainQ($code) {
		$sql = mysqli_query($link,$code);
	}

	//Get additional data
	$sql = mysqli_query($link,"SELECT id, asset_type FROM assets WHERE asset_tag = '$scan' LIMIT 1"); //CHECK THAT IT IS CALLED ASSET_TAG
	$row = mysqli_fetch_array($sql);
	$id = $row["id"];
	$aType = $row["asset_type"];

	//Update asset
	mainQ("UPDATE assets SET assigned_to = NULL, updated_at = '$friendlyDate', last_checkout = NULL, expected_checkin = NULL WHERE id = '$id'");

	//Create log
	mainQ("INSERT INTO asset_logs(user_id,action_type,asset_id,checkedout_to,location_id,created_at,asset_type,note,updated_at) VALUES ('$sender','checkin from','$id',???,NULL,'$friendlyDate','$aType','$notes','$friendlyDate')");
?>