<?php
	include "db/connect.php";

	$json = file_get_contents("php://input");
	$listData = json_decode($json,true);

	$tag = $listData["tag"];
	$table = $listData["table"];
	$col = $listData["col"];

	$out = -1;

	$sql = mysqli_query($link,"SELECT id FROM ".$table." WHERE ".$col." = '$tag' LIMIT 1");
	if (mysqli_num_rows($sql) > 0) {
		while ($row = mysqli_fetch_array($sql)) {
			$out = $row["id"];
		}
	}

	mysqli_close($link);
	echo $out;
?>