<!--

~~ Checkout Information ~~

DB: snipeit
Table: asset_logs  &&  assets

asset_logs Columns:
id: Auto
user_id: int User of program - Default for desk?
action_type: checkout
asset_id: int Returned from scan
checkedout_to: int Returned from swipe text (Employee No.)
location_id: int Returned from swipe - Set location of the user
created_at: timestamp, yyyy-mm-dd hh:mm:ss
asset_type: From data returned from scan
note: Notes field
updated_at: Same as created_at



asset Columns (where id = id of asset by tag (auto-incr from 1)):
assigned_to: int User ID returned from query from swiped Employee No.
Updated_at: timestamp, yyyy-mm-dd hh:mm:ss (same as created_at from other table)
last_checkout: timestamp, same as before, yyyy-mm-dd hh:mm:ss
expected_checkin: Date Expected Back Field, yyyy-mm-dd

-->

<?php
	//Get and store date
	ini_set('date.timezone','EST');
	$date = new DateTime();
	$friendlyDate = $date->format('m-d-Y H:i:s');

	//DB conn
	include "db/connect.php";

	//Decode data
	$json = file_get_contents('php://input');
	$listData = json_decode($json,true);

	//Store data posted
	$swipe = $listData["swipe"];
	$scan = $listData["scan"];
	$notes = $listData["notes"];
	$expected = $listData["expected"];

	//Default helpdesk user ID
	$sender = 1;

	//Queries because typing takes too long
	function mainQ($code) {
		$sql = mysqli_query($link,$code);
	}

	//Get additional data
	$sql = mysqli_query($link,"SELECT id, asset_type FROM assets WHERE asset_tag = '$scan' LIMIT 1"); //CHECK THAT IT IS CALLED ASSET_TAG
	$row = mysqli_fetch_array($sql);
	$aid = $row["id"];
	$aType = $row["asset_type"];

	$sql = mysqli_query($link,"SELECT id, location FROM users WHERE employee_num = '$swipe' LIMIT 1"); //CHECK THAT IT IS CALLED employee_num
	$row = mysqli_fetch_array($sql);
	$uid = $row["id"];
	$loc = $row["location"];

	//Update asset
	mainQ("UPDATE assets SET assigned_to='$uid',updated_at='$friendlyDate',last_checkout='$friendlyDate',expected_checkin='$expected'");

	//Create log
	mainQ("INSERT INTO asset_logs(user_id,action_type,asset_id,checkedout_to,location_id,created_at,asset_type,note,updated_at) VALUES ('$sender','$checkout','$aid','$uid','$loc','$friendlyDate','$aType','$notes','$friendlyDate'");
?>