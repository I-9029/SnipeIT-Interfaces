<!--

DB: snipeit
Table: assets

$tag = $_POST["tag"];
$query = "SELECT id FROM assets WHERE asset_tag = '$tag' LIMIT 1";

$result = mysql_query($query);
$row = mysql_fetch_assoc($result);
$id = $row['id'];

body:
    <?php //echo $id; ?>

-->

<?php
	include "db/connect.php";

	$json = file_get_contents("php://input");
	$listData = json_decode($json,true);

	$tag = $listData["tag"];
	$out = -1;

	$sql = mysqli_query($link,"SELECT id FROM assets WHERE asset_tag = '$tag' LIMIT 1");
	if (mysqli_num_rows($sql) > 0) {
		$row = mysqli_fetch_array($sql));
		$out = $row["id"];
	}

	mysqli_close($link);
	echo $out;
?>