
<!--

DB: snipeit
Table: users

$card = $_POST["card"];
$query = "SELECT id FROM users WHERE employee_num = '$card' LIMIT 1";

$result = mysql_query($query);
$row = mysql_fetch_assoc($result);
$id = $row['id'];

body:
    <?php //echo $id ?>

-->

<?php
	include "db/connect.php";

	$json = file_get_contents("php://input");
	$listData = json_decode($json,true);

	$tag = $listData["tag"];
	$out = -1;

	$sql = mysqli_query($link,"SELECT id FROM users WHERE employee_num = '$tag' LIMIT 1");
	if (mysqli_num_rows($sql) > 0) {
		$row = mysqli_fetch_array($sql));
		$out = $row["id"];
	}

	mysqli_close($link);
	echo $out;
?>