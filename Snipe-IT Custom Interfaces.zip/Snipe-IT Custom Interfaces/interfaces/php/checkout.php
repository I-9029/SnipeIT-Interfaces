<!--

~~ Checkout Information ~~

DB: snipeit
Table: asset_logs  &&  assets

asset_logs Columns:
id: Auto
user_id: int User of program - Default for desk?
action_type: checkout
asset_id: int Returned from scan
checkedout_to: int Returned from swipe text (Employee No.)
location_id: int Returned from swipe - Set location of the user
created_at: timestamp, yyyy-mm-dd hh:mm:ss
asset_type: From data returned from scan
note: Notes field
updated_at: Same as created_at



asset Columns (where id = id of asset by tag (auto-incr from 1)):
assigned_to: int User ID returned from query from swiped Employee No.
Updated_at: timestamp, yyyy-mm-dd hh:mm:ss (same as created_at from other table)
last_checkout: timestamp, same as before, yyyy-mm-dd hh:mm:ss
expected_checkin: Date Expected Back Field, yyyy-mm-dd

-->

<?php
	//Get and store date
	date_default_timezone_set('America/New_York'); 
	$date = new DateTime();
	$friendlyDate = $date->format('Y-m-d H:i:s');

	//DB conn
	include "db/connect.php";

	//Store data posted
	$swipe = $_GET["swipe"];
	$scan = $_GET["scan"];
	$notes = $_GET["notes"];
	$expected = $_GET["expected"];

	//Default helpdesk user ID
	$sender = 1;

	//Queries because typing takes too long
	function mainQ($link,$code) {
		mysqli_query($link,$code) or die("Error: ".mysqli_error($link));
	}

	//Get additional data
	$sql = mysqli_query($link,"SELECT id,assigned_to FROM assets WHERE asset_tag = '$scan' AND requestable = 1 LIMIT 1");
    if (mysqli_num_rows($sql) > 0) {
        $row = $sql->fetch_assoc();
        $aid = $row["id"];
        $asignee = $row["assigned_to"];
        if ($asignee) {
            die("Asset is already checked out.");
        }
    } else {
        die("There is no matching asset.");
    }

	$sql = mysqli_query($link,"SELECT id, location_id FROM users WHERE employee_num = '$swipe' AND deleted_at IS NULL LIMIT 1");
    if (mysqli_num_rows($sql) > 0) {
        $row = $sql->fetch_assoc();
        $uid = $row["id"];
        $loc = $row["location_id"];
    } else {
        die("There is no matching user.");
    }

	//Update asset
	mainQ($link,"UPDATE assets SET assigned_to='$uid',updated_at=STR_TO_DATE('$friendlyDate','%Y-%m-%d %H:%i:%s'),last_checkout=STR_TO_DATE('$friendlyDate','%Y-%m-%d %H:%i:%s'),expected_checkin=STR_TO_DATE('$expected','%Y-%m-%d') WHERE id='$aid'");

	//Create log
	mainQ($link,"INSERT INTO asset_logs(user_id,action_type,asset_id,checkedout_to,location_id,created_at,asset_type,note,updated_at) VALUES ('$sender','checkout','$aid','$uid','$loc',STR_TO_DATE('$friendlyDate','%Y-%m-%d %H:%i:%s'),'hardware','$notes',STR_TO_DATE('$friendlyDate','%Y-%m-%d %H:%i:%s'))");
    
    //Sucess
    mysqli_close($link);
    echo "Asset successfully checked out!";
?>