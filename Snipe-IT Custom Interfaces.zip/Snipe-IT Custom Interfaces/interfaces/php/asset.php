<!--

DB: snipeit
Table: assets

$tag = $_POST["tag"];
$query = "SELECT id FROM assets WHERE asset_tag = '$tag' LIMIT 1";

$result = mysql_query($query);
$row = mysql_fetch_assoc($result);
$id = $row['id'];

body:
    <?php echo $id ?>

-->