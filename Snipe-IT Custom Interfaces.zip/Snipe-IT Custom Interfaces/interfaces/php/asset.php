<!--

DB: snipeit
Table: assets

$query = "SELECT id FROM assets WHERE asset_tag = '$tag' LIMIT 1";

$result = mysql_query($query);
$row = mysql_fetch_assoc($result);
$id = $row['id'];

Redirect:
header("../../snipeit/public/index.php/hardware/".$id."/view")

-->