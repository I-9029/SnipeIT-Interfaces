<?php
        include "db/connect.php";

        //Get employee_num
        $tag = $_GET["tag"];
        $out = -1;

        $sql = mysqli_query($link,"SELECT id FROM assets WHERE asset_tag = '$tag' LIMIT 1");
        //Rows exist
        if (mysqli_num_rows($sql) > 0) {
                //Set vars
                $row = mysqli_fetch_row($sql);
                $out = $row[0];
        }

        //Close and output
        mysqli_close($link);
        echo $out;
?>
