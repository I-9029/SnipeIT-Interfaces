
<!--

DB: snipeit
Table: users

$query = "SELECT id FROM users WHERE employee_num = '$card' LIMIT 1";

$result = mysql_query($query);
$row = mysql_fetch_assoc($result);
$id = $row['id'];

Redirect:
header("../../snipeit/public/index.php/admin/users/".$id."/view")

-->