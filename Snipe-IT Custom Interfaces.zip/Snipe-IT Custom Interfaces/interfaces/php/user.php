
<!--

DB: snipeit
Table: users

$card = $_POST["card"];
$query = "SELECT id FROM users WHERE employee_num = '$card' LIMIT 1";

$result = mysql_query($query);
$row = mysql_fetch_assoc($result);
$id = $row['id'];

body:
    <?php echo $id ?>

-->