<!--

~~ Checkout Information ~~

DB: snipeit
Table: asset_logs  &&  assets

asset_logs Columns:
id: Auto
user_id: int User of program - Default for desk?
action_type: checkout
asset_id: int Returned from scan
checkedout_to: 1+, ID, Returned from swipe text (Employee No.)
location_id: NULL
created_at: timestamp, yyyy-mm-dd hh:mm:ss
asset_type: From data returned from scan
note: Notes field
updated_at: Same as created_at



asset Columns (where id = id of asset by tag (auto-incr from 1)):
assigned_to: NULL
Updated_at: timstamp, yyyy-mm-dd hh:mm:ss (same as created_at from other table)
last_checkout: NULL
expected_checkin: NULL

-->