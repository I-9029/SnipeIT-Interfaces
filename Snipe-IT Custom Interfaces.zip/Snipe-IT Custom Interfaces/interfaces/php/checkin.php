<!--

~~ Check-in Information ~~

DB: snipeit
Table: asset_logs  &&  assets

asset_logs Columns:
id: Auto
user_id: int User of program - Default for desk?


//Double check this value!\\
action_type: checkin from


asset_id: int Returned from scan
checkedout_to: ???????							//DOUBLE CHECK
location_id: NULL
created_at: timestamp, yyyy-mm-dd hh:mm:ss
asset_type: From data returned from scan
note: Notes field
updated_at: Same as created_at



asset Columns (where id = id of asset by tag (auto-incr from 1)):
assigned_to: NULL
Updated_at: timstamp, yyyy-mm-dd hh:mm:ss (same as created_at from other table)
last_checkout: NULL
expected_checkin: NULL

-->
<?php
	//Get and store date
	date_default_timezone_set('America/New_York'); 
	$date = new DateTime();
	$friendlyDate = $date->format('Y-m-d H:i:s');
    
    //Errors please
    ini_set('display_errors', 'On');

	//DB conn
	include "db/connect.php";

	//Store data posted
	$scan = $_GET["scan"];
	$notes = $_GET["notes"];

	//Default helpdesk user ID
	$sender = 1;

	/*
	We need:
		ID from Assets
		Asset Type from Assets
		Notes passed in post
	*/

	//Queries because typing takes too long
	function mainQ($link,$code) {
		mysqli_query($link,$code) or die("Error: ".mysqli_error($link));
	}

	//Get additional asset data
	$sql = mysqli_query($link,"SELECT id,assigned_to FROM assets WHERE asset_tag = '$scan' AND requestable = 1 LIMIT 1");
    //Rows exist
    if (mysqli_num_rows($sql) > 0) {
            //Set vars
            $row = $sql->fetch_assoc();
            $aid = $row["id"];
            $asignee = $row["assigned_to"];
            if (!$asignee) {
                die("This asset is not checked out.");
            }
    } else {
        die("There is no matching asset.");
    }
    
    //Get additional data
	$sql = mysqli_query($link,"SELECT checkedout_to,id FROM asset_logs WHERE asset_id = '$aid' ORDER BY id DESC LIMIT 1");
    if (mysqli_num_rows($sql) > 0) {
        $row = $sql->fetch_assoc();
        $uid = $row["checkedout_to"];
    } else {
        die("There is no matching log for this asset.");
    }

	//Update asset
	mainQ($link,"UPDATE assets SET assigned_to = NULL, updated_at = STR_TO_DATE('$friendlyDate','%Y-%m-%d %H:%i:%s'), last_checkout = NULL, expected_checkin = NULL WHERE id = '$aid'");

	//Create log
	mainQ($link,"INSERT INTO asset_logs(user_id,action_type,asset_id,checkedout_to,location_id,created_at,asset_type,note,updated_at) VALUES ('$sender','checkin from','$aid','$uid',NULL,STR_TO_DATE('$friendlyDate','%Y-%m-%d %H:%i:%s'),'hardware','$notes',STR_TO_DATE('$friendlyDate','%Y-%m-%d %H:%i:%s'))");
    
    $link->close();
    //Completed Successfully
    echo "Asset successfully checked in!";
?>