<?php
	$link = mysqli_connect("localhost","dataQ","thine0wn","snipeit");
	if ($link === false) { die("Error: Could not connect. ".mysqli_connect_error()); }
?>
